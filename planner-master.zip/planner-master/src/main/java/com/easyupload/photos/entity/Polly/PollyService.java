package com.easyupload.photos.entity.Polly;

public interface PollyService {
	public String generateVoiceInvite(String eventId, String userName, String date, String time, String eventDesc);
}
